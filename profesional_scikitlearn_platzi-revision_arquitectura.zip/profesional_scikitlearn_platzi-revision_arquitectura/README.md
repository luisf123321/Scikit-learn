# profesional_scikitlearn_platzi
Repositorio de código usado durante el Curso Profesional de Scikit-Learn para Platzi.
